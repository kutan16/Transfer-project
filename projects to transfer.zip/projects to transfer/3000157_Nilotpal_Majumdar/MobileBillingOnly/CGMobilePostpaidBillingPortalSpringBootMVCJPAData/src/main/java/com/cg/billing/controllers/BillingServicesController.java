package com.cg.billing.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.beans.Customer;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.services.BillingServices;
@Controller
public class BillingServicesController {
	@Autowired
	BillingServices billingServices;
	@RequestMapping("/registerCustomer")
	public ModelAndView registerAssociate(@ModelAttribute Customer customer){
		customer=billingServices.acceptCustomerDetails(customer);
		return new ModelAndView("registrationPage","customer",customer);
	}
	@RequestMapping("/associateDetails")
	public ModelAndView getCustomerDetails(@RequestParam int customerId)throws CustomerDetailsNotFoundException{
		Customer customer=billingServices.getCustomerDetails(customerId);
		return new ModelAndView("findCustomerDetailsPage","customer",customer);
	}
}
