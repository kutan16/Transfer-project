package com.cg.billing.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.daoservices.BillDAO;
import com.cg.billing.daoservices.CustomerDAO;
import com.cg.billing.daoservices.PlanDAO;
import com.cg.billing.daoservices.PostPaidAccountDAO;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;

@Component("bankingServices")
public class BillingServicesImpl implements BillingServices {

	@Autowired
	private PlanDAO planDao;
	@Autowired
	private CustomerDAO customerDao;
	@Autowired
	private BillDAO billDao;
	@Autowired
	private PostPaidAccountDAO postPaidAccountDao;
	

//	@Override
//	public List<Plan> getPlanAllDetails() {
//		return PlanDAO.findAllPlanDetails();
//	}

	@Override
	public Customer acceptCustomerDetails(Customer customer) {
//		return CustomerDAO.save(customer).getCustomerID();
		return customerDao.save(customer);
	}

//	@Override
//	public long openPostpaidMobileAccount(int customerID, int planID)
//			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
//		Customer customer = CustomerDAO.findOne(customerID);
//		if(customer == null)
//			throw new CustomerDetailsNotFoundException();
//		Plan plan = PlanDAO.findPlanDetails(planID);
//		if(plan == null)
//			throw new PlanDetailsNotFoundException();
//		PostpaidAccount postpaidAccount = new PostpaidAccount(plan, customer);
//		return PostpaidAccountDAO.postPaidAccountSave(plan, postpaidAccount).getMobileNo();
//	}

	@Override
	public double generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException {
		double amount = 0;
		Customer customer = customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException());
		if(customer == null)
			throw new CustomerDetailsNotFoundException();
		PostpaidAccount postpaidAccount = postPaidAccountDao.findById((int) mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException());
		if(postpaidAccount == null)
			throw new PostpaidAccountNotFoundException();
		List<Bill> postPaidBillList = new ArrayList<Bill>(postpaidAccount.getBills().values());
		for (Bill bill : postPaidBillList) {
			if(bill.getBillMonth().equals(billMonth)) {
				amount += (noOfStdSMS * bill.getStdSMSAmount()) + (noOfLocalSMS * bill.getLocalSMSAmount()) 
						+(noOfLocalCalls * bill.getLocalCallAmount()) + (noOfStdCalls * bill.getStdCallAmount())
						+(internetDataUsageUnits * bill.getInternetDataUsageAmount());
			}
		}
		return amount;
	}

	@Override
	public Customer getCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
		Customer customer = customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException());
		return customer;
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		return customerDao.findAll();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException());
		PostpaidAccount postpaidAccount = postPaidAccountDao.findById((int) mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException());
		return postpaidAccount;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException {
		Customer customer = customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException());
		return new ArrayList<PostpaidAccount>(customer.getPostpaidAccounts().values());
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException {
		Bill b = null;
		customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException());
		PostpaidAccount postpaidAccount = postPaidAccountDao.findById((int) mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException());
		if(!billMonth.equalsIgnoreCase("January") || !billMonth.equalsIgnoreCase("February") || !billMonth.equalsIgnoreCase("March")
				|| !billMonth.equalsIgnoreCase("April") || !billMonth.equalsIgnoreCase("May") || !billMonth.equalsIgnoreCase("June")
				|| !billMonth.equalsIgnoreCase("July") || !billMonth.equalsIgnoreCase("August") || !billMonth.equalsIgnoreCase("September")
				|| !billMonth.equalsIgnoreCase("October") || !billMonth.equalsIgnoreCase("November") || !billMonth.equalsIgnoreCase("December"))
			throw new InvalidBillMonthException();
		List<Bill> billList = new ArrayList<Bill>(postpaidAccount.getBills().values());
		for (Bill bill : billList) {
			if(bill.getBillMonth().equals(billMonth)) {
				b = bill;
				break;
			}
		}
		return b;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException());
		PostpaidAccount postpaidAccount = postPaidAccountDao.findById((int) mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException());
		return new ArrayList<Bill>(postpaidAccount.getBills().values());
		
	}
//
//	@Override
//	public boolean changePlan(int customerID, long mobileNo, int planID)
//			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
//		customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException());
//		PostpaidAccount postpaidAccount = postPaidAccountDao.findById((int) mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException());
//		Plan plan = planDao.findById(planID).orElseThrow(()->new PlanDetailsNotFoundException());
//		if(postpaidAccount.getPlan().equals(plan))
//			return planDao.save(plan);
//		return false;
//	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		postPaidAccountDao.findById(customerID).orElseThrow(()->new PostpaidAccountNotFoundException());
		customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException());
		postPaidAccountDao.deleteById(customerID);
		return true;
	}

	@Override
	public boolean removeCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
		customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException());
		customerDao.deleteById(customerID);
		return true;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
		PostpaidAccount postpaidAccount = postPaidAccountDao.findById(customerID).orElseThrow(()->new PostpaidAccountNotFoundException());
		customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException());
		Plan plan = postpaidAccount.getPlan();
		if(plan == null)
			throw new PlanDetailsNotFoundException();
		return plan;
	}
	@Override
	public Customer acceptCustomerDetails(String firstName, String lastName, String emailID, String dateOfBirth,
			String billingAddressCity, String billingAddressState, int billingAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public PostpaidAccount openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Plan> getPlanAllDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		// TODO Auto-generated method stub
		return false;
	}

}