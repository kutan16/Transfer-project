function validateLoginFrm() {
	if(loginForm.associateId.value==""){
		alert("Enter AssociateId");
		return false;
	}
	else if(loginForm.password.value==""){
		alert("Enter Password");
		return false;
	}
}
function validateRegistrationFrm() {
	if(registerForm.firstName.value==""){
		alert("Enter first name");
		return false;
	}
	else if(registerForm.lastName.value==""){
		alert("Enter last name");
		return false;
	}
	else if(registerForm.emailId.value==""){
		alert("Enter Email id");
		return false;
	}
	else if(registerForm.department.value==""){
		alert("Enter department");
		return false;
	}
	else if(registerForm.designation.value==""){
		alert("Enter designation");
		return false;
	}
	else if(registerForm.panCard.value==""){
		alert("Enter pancard");
		return false;
	}
	else if(registerForm.yearlyInvestmentUnder80C.value==""){
		alert("Enter yearlyInvestmentUnder80c");
		return false;
	}
	else if(registerForm.basicSalary.value==""){
		alert("Enter basic salary");
		return false;
	}
	else if(registerForm.bankName.value==""){
		alert("Enter bank name");
		return false;
	}
	else if(registerForm.accountNumber.value==""){
		alert("Enter account number");
		return false;
	}
	else if(registerForm.ifscCode.value==""){
		alert("Enter ifsc code");
		return false;
	}
}
	
	function validatePassword(){
		if(changePasswordFrm.password.value.length>=6){
			if(changePasswordFrm.password.value.search(/[0-0]/)!=-1 &&
					changePasswordFrm.password.value.search(/[A-Z]/)!=-1 &&
							changePasswordFrm.password.value.search(/[!@#$%^&*()_+]/)!=-1){
				return true;
			}
		else{
			alert("password must contain atleast 1 number 1 uppercase letter and 1 special character");
		return false;
		}
	}
	else{
		alert("minimum of 6 characters");
		return false;
	}
}

function checkSame(){
	if(changePasswordFrm.password.value!=changePasswordFrm.confirmPassword.value){
		alert("password abd confirm password did not match");
		return false;
	}
}