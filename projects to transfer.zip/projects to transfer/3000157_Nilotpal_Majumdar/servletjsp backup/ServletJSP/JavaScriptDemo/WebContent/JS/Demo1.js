function sayHello() {
	document.getElementById("msg").innerHTML="<font color='red' size='10'>Helo World on browser</font>"
	console.log("Hello World on console")
}
function sayHello1() {
	alert("This is an alert msg")
}