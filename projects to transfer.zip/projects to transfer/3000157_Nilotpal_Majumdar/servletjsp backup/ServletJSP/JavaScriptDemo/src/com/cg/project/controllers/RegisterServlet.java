package com.cg.project.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.omg.PortableInterceptor.SUCCESSFUL;

import com.cg.project.beans.Associate;
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int associateId=Integer.parseInt(request.getParameter("associateId"));
		String password = request.getParameter("password");
		String firstname =request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String email = request.getParameter("email");
		String graduation=request.getParameter("graduation");
		int mobile=Integer.parseInt(request.getParameter("mobile"));
		String gender=request.getParameter("gender");
		List<String> communication=Arrays.asList(request.getParameterValues("communication"));
		
		Associate associate=new Associate(associateId, password,firstname,lastname,email,graduation,mobile,gender,communication);
		RequestDispatcher dispatcher=request.getRequestDispatcher("WelcomePage.jsp");

		
		
	}

}
