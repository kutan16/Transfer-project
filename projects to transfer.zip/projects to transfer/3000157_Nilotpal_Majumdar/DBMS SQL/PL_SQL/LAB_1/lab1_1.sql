DECLARE
V_Sample1 NUMBER(2);
V_Sample2 CONSTANT NUMBER(2) := 5 ;
V_Sample3 NUMBER(2) NOT NULL := 5;
V_Sample4 NUMBER(2) := 50;
V_Sample5 NUMBER(2) DEFAULT 25;
BEGIN
dbms_output.put_line(V_Sample2);
dbms_output.put_line(V_Sample3);
dbms_output.put_line(V_Sample4);
dbms_output.put_line(V_Sample5);
END;
/
