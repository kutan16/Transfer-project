--1---------------------------------------------------------------------
create table employee as select * from emp where 1=3

desc employee

select * from employee
--2---------------------------------------------------------------------
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, SAL, DEPTNO) VALUES ('7934', 'miller', '1300', '10')
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, SAL, DEPTNO) VALUES ('7902', 'ford', '3000', '20')
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, SAL, DEPTNO) VALUES ('7900', 'james', '950', '30')
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, SAL, DEPTNO) VALUES ('7876', 'adams', '1100', '20')
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, SAL, DEPTNO) VALUES ('7844', 'turner', '1500', '30')
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, SAL, DEPTNO) VALUES ('7839', 'king', '5000', '10')
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, SAL, DEPTNO) VALUES ('7788', 'scott', '3000', '20')
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, SAL, DEPTNO) VALUES ('7782', 'clark', '2450', '10')
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, SAL, DEPTNO) VALUES ('7698', 'blake', '2850', '30')
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, SAL, DEPTNO) VALUES ('7654', 'martin', '1250', '30')
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, SAL, DEPTNO) VALUES ('7566', 'jones', '2975', '20')
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, SAL, DEPTNO) VALUES ('7521', 'ward', '1250', '30')
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, SAL, DEPTNO) VALUES ('7499', 'allen', '1600', '30')
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, SAL, DEPTNO) VALUES ('7369', 'smith', '800', '20')
--3---------------------------------------------------------------------
update employee set job=(select job from employee where empno=7788),
deptno=(select deptno from employee where empno=7788) where empno=7698
--4---------------------------------------------------------------------
delete from department_master where dept_name='sales'
--5---------------------------------------------------------------------
update employee set deptno =(select deptno from employee
where empno=7698) where empno=7788
--6---------------------------------------------------------------------
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, JOB, MGR, HIREDATE, SAL, COMM, DEPTNO) VALUES ('1000', 'allen', 'cleark', '1001', TO_DATE('12-jan-01', 'DD-MON-RR'), '3000', '2', '10')
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, JOB, HIREDATE, SAL, COMM, DEPTNO) VALUES ('1001', 'george', 'analyst', TO_DATE('08-sep-92', 'DD-MON-RR'), '5000', '0', '10')
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, JOB, MGR, HIREDATE, SAL, COMM, DEPTNO) VALUES ('1002', 'becker', 'manager', '1000', TO_DATE('04-nov-92', 'DD-MON-RR'), '2800', '4', '20')
INSERT INTO SYSTEM."EMPLOYEE" (EMPNO, ENAME, JOB, MGR, HIREDATE, SAL, COMM, DEPTNO) VALUES ('1003', 'bill', 'clerk', '1002', TO_DATE('04-nov-92', 'DD-MON-RR'), '3000', '0', '20')
------------------------------------------------------------------------