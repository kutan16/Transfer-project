--1--------------------------------------------------------------------
INSERT INTO SYSTEM."CUSTOMERMASTER" (CUSTOMERID, CUSTOMERNAME, ADDRESS1, ADDRESS2, GENDER, AGE, PHONENO,SALARY) VALUES ('6000', 'john', '#115 Chicago', '#115 Chicago', 'M', '25', '7878776',10000')
INSERT INTO SYSTEM."CUSTOMERMASTER" (CUSTOMERID, CUSTOMERNAME, ADDRESS1, ADDRESS2, GENDER, AGE, PHONENO,SALARY) VALUES ('6001', 'jack', '#116 France', '#116 France', 'M', '25', '434524'.'20000')
INSERT INTO SYSTEM."CUSTOMERMASTER" (CUSTOMERID, CUSTOMERNAME, ADDRESS1, ADDRESS2, GENDER, AGE, PHONENO,SALARY) VALUES ('6002', 'james', '#114 New York', '#114 New York', 'M', '45', '431525'.'15000.50')
--2--------------------------------------------------------------------
savepoint sp1
--3--------------------------------------------------------------------
INSERT INTO SYSTEM."CUSTOMERMASTER" (CUSTOMERID, CUSTOMERNAME, ADDRESS1, ADDRESS2, GENDER, AGE, PHONENO,SALARY) VALUES ('6003', 'john', '#114 Chicago', '#114 Chicago', 'M', '45', '439525','19000.60')
--4--------------------------------------------------------------------
rollback to sp1