--3.1
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--1
SELECT staff_name, D.dept_code, D.dept_name, staff_sal from Staff_Master S,Department_Master D where D.dept_code=S.dept_code AND staff_sal>20000;
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--2
 SELECT staff_code STAFF#, staff_name STAFF, D.dept_name,MGR_CODE Mgr#, (SELECT staff_name from Staff_master where Staff_CODE=S.MGR_CODE) "Manager"  from Staff_Master S,Department_Master D where D.dept_code=S.dept_code;
 ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 --3
 SELECT S.STUDENT_CODE, STUDENT_NAME, T.BOOK_CODE, B.BOOK_NAME from STUDENT_MASTER S, BOOK_MASTER B, BOOK_TRANSACTIONS T where S.STUDENT_CODE = T.STUDENT_CODE AND T.BOOK_CODE = B.BOOK_CODE AND BOOK_EXPECTED_RETURN_DATE = SYSDATE;
 ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 --4
 select s.staff_code, s.staff_name, d.dept_name, e.job, b.book_code, b1.book_name, b.book_issue_date from staff_master s, department_master d, book_transactions b, emp e, book_master b1 where s.dept_code=d.dept_code and s. staff_code=b.staff_code and b.book_code=b1.book_code and e.job=d.dept_name and b.book_issue_date<=sysdate-30;
 ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 --6
 SELECT  STAFF_CODE, STAFF_NAME, STAFF_SAL FROM STAFF_MASTER WHERE STAFF_SAL <(SELECT AVG(STAFF_SAL) FROM STAFF_MASTER);
  ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  --7
select BOOK_PUB_AUTHOR, BOOK_NAME FROM BOOK_MASTER WHERE BOOK_PUB_AUTHOR IN (select BOOK_PUB_AUTHOR FROM BOOK_MASTER GROUP BY BOOK_PUB_AUTHOR having COUNT(BOOK_PUB_AUTHOR) > 1);
 ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 --8
 SELECT staff_code, staff_name, (SELECT dept_name from department_master where dept_Code=S.dept_code) "DEPARTMENT NAME" from staff_master S where staff_code IN (select staff_code from book_transactions);
  ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  --9
  Select student_code, student_name, dept_name from department_master d, student_master s where s.dept_code=d.dept_code and d.dept_code=(select * from (select dept_code from student_master group by dept_code order by count(student_code) desc) where rownum=1);
  ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  --10
  Select * from (select s.staff_code, staff_name, dept_name, design_name, min(sysdate � hiredate)/365 from staff_master s, department_master d, designation_master c where s.dept_code=d.dept_code and s.design_code=c.design_code group by s.staff_code, staff_name, dept_name, design_name order by min(sysdate-hiredate)/365) where rownum=1;
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--11
select staff_name"MANAGER NAME", (select count(staff_code) from staff_master where mgr_code=S.staff_code)"TOTAL STRENGTH" from staff_master S where staff_code IN (select mgr_code from staff_master) ;
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

