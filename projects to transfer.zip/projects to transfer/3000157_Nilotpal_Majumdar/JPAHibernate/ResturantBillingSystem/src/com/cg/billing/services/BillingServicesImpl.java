package com.cg.billing.services;
import java.util.List;

import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Dish;
import com.cg.billing.daoservices.CustomerDAO;
import com.cg.billing.daoservices.CustomerDAOImpl;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
public class BillingServicesImpl  implements BillingServices{
	private CustomerDAO customerDao=new CustomerDAOImpl();
	public BillingServicesImpl(CustomerDAO mockCustomerDao) {
		// TODO Auto-generated constructor stub
	}
	public BillingServicesImpl() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, int phone, int starter,int mainCourse, int desert) {
		int billNo=(int) Math.random()*1000+56;
		Customer customer =new Customer(firstName,lastName,emailId,phone,new Dish(starter,mainCourse,desert),new Bill(billNo));
		customer=customerDao.save(customer);
		return customer.getCustomerId();
	}
	@Override
	public double calculateTotalBillAmount(int customerId) throws CustomerDetailsNotFoundException {
		Customer customer=customerDao.findOne(customerId);
		return ((customer.getDishes().getStarter()+customer.getDishes().getMainCourse()+customer.getDishes().getDesert())*(1.18));
	}
	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerDetailsNotFoundException {
		Customer customer=customerDao.findOne(customerId);
		if(customer==null)
			throw new CustomerDetailsNotFoundException("Customer Details not found for Id "+customerId);
		return customer;
	}
	@Override
	public List<Customer> getAllCustomerDetails() {
		return customerDao.findAll();
	}
	
	
	
}