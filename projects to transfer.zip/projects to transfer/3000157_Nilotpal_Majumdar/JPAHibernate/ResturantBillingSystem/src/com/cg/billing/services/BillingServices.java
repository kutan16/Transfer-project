package com.cg.billing.services;
import java.util.List;

import com.cg.billing.beans.Customer;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
public interface BillingServices {
	int acceptCustomerDetails(String firstName, String lastName, String emailId, int phone, int starter, int mainCourse,int desert);
	double calculateTotalBillAmount(int customerId) throws CustomerDetailsNotFoundException;
	Customer getCustomerDetails(int customerId) throws CustomerDetailsNotFoundException;
	List<Customer> getAllCustomerDetails();
}
