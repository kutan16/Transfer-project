package com.cg.ticketing.exceptions;

public class InvalidNameException extends Exception {

}
