package com.cg.billing.dao;

import java.util.HashMap;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.billing.beans.Customer;


public class CustomerDaoImpl implements CustomerDAO{
	private EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU");

	@Override
	public Customer save(Customer customer) {
EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		entityManager.getTransaction().begin();
		entityManager.persist(customer);
		entityManager.getTransaction().commit();
		entityManager.close();
		
		return customer;		
	}

	@Override
	public boolean update(Customer customer) {
EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		entityManager.getTransaction().begin();
		entityManager.merge(customer);
		entityManager.getTransaction().commit();
		entityManager.close();
				return false;
	}

	@Override
	public Customer findOne(int customerId) {
		return entityManagerFactory.createEntityManager().find(Customer.class, customerId);

	}

	@Override
	public HashMap<Integer, Customer> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean remove(Customer customer) {
EntityManager entityManager=entityManagerFactory.createEntityManager();
		
		entityManager.getTransaction().begin();
		entityManager.remove(customer);
		entityManager.getTransaction().commit();
		entityManager.close();
				return false;		
	}

}
