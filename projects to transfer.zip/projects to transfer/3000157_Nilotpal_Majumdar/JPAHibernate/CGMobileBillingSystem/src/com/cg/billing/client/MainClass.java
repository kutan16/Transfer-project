package com.cg.billing.client;

import java.util.Scanner;

import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServiceImpl;
import com.cg.billing.services.BillingServices;

public class MainClass {

	public static void main(String[] args) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException  {		
		BillingServices services = new BillingServiceImpl();
//		BankingServicesImpl account = new BankingServicesImpl();
		//long accountNoTo,accountNoFrom,transferAmount;
		
		while(true) {
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your choice");
		System.out.println("1. create Postpaid Account");
		System.out.println("2. get Customer details");
		System.out.println("3. get every Customer details");
		System.out.println("4.Change Plan ");
	
		System.out.println("6.Accept Customer Details");
		System.out.println("7.Close PostPaid Account");
		System.out.println("8.Remove Customer Details");
		System.out.println("9.Get Customer All Plan Details");
		System.out.println("10.Get All PostPaid Account Details");
		System.out.println("11.For Exit");
		int n = sc.nextInt();
		switch(n) {
		case 1:	System.out.println("Enter The Customer Id");
						int customerID=sc.nextInt();
//						System.out.println("Enter The Mobile No");
//						long mobileNo=sc.nextLong();
						System.out.println("Enter The Plan Id");
						int planId=sc.nextInt();
						services.openPostpaidMobileAccount(customerID, planId);
		case 2:	System.out.println("Enter The Customer Id");
						int customerID6=sc.nextInt();
						services.getCustomerDetails(customerID6);
		case 3: 	System.out.println(services.getAllCustomerDetails());
		case 7:  System.out.println("Enter The Customer Id");
						int customerID3=sc.nextInt();
						System.out.println("Enter The Mobile No");
						long mobileNo3=sc.nextLong();
						services.closeCustomerPostPaidAccount(customerID3, mobileNo3);
		case 8: System.out.println("Enter The Customer Id");
						int customerID5=sc.nextInt();		
						services.removeCustomerDetails(customerID5);
		case 9:	System.out.println(services.getPlanAllDetails());
		case 10:{System.out.println("Enter The Customer Id");
						int customerID2=sc.nextInt();
						System.out.println(services.getCustomerAllPostpaidAccountsDetails(customerID2));}
		case 11: System.exit(0);
		default: 
			System.out.println("enter correct choice");
		}
	}
	}
}

