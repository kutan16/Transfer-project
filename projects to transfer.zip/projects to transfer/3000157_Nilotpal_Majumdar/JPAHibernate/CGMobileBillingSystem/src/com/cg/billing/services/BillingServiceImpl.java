package com.cg.billing.services;
import java.util.List;

import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.dao.BillDAO;
import com.cg.billing.dao.CustomerDAO;
import com.cg.billing.dao.CustomerDaoImpl;
import com.cg.billing.dao.PlanDAO;
import com.cg.billing.dao.PlanDaoImpl;
import com.cg.billing.dao.PostPaidAccountDAO;
import com.cg.billing.dao.PostPaidAcocuntDaoImpl;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;

public class BillingServiceImpl implements BillingServices{
	private BillDAO billDao;
	 CustomerDAO customerDao=new CustomerDaoImpl() ;		
	 PlanDAO planDao=new PlanDaoImpl();
	 PostPaidAccountDAO postpaidDao=new PostPaidAcocuntDaoImpl();
	Plan plans=new Plan();
	Bill bills=new Bill();
	PostpaidAccount postPaidAccount=new PostpaidAccount();
	Customer customer=new Customer();
	public BillingServiceImpl(BillDAO billDao, CustomerDAO customerDao, PlanDAO planDao, PostPaidAccountDAO postpaidDao) {
		super();
		this.billDao = billDao;
		this.customerDao = customerDao;
		this.planDao = planDao;
		this.postpaidDao = postpaidDao;
	}

	public BillingServiceImpl() {}

	@Override
	public List<Plan> getPlanAllDetails() {
		return (List<Plan>) planDao.findAll();
	}

	@Override
	public int acceptCustomerDetails(Customer customer) {
		customer=customerDao.save(customer);
		return customer.getCustomerID();
	}

	@Override
	public PostpaidAccount openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		PostpaidAccount postpaidAccount= postpaidDao.save(new PostpaidAccount(customer.getCustomerID(),plans.getPlanID()));
		if(customerID==0)
			throw new CustomerDetailsNotFoundException();
		else if(planID==0)
			throw new PlanDetailsNotFoundException();
		else
		return postpaidAccount;
	}

	@Override
	public double generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
					throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException {
		double totalBillAmount=(bills.getNoOfLocalCalls()-plans.getFreeLocalCalls())*plans.getLocalCallRate()+
				(bills.getNoOfLocalSMS()-plans.getFreeLocalSMS())*plans.getLocalSMSRate()+
				(bills.getNoOfStdCalls()-plans.getFreeStdCalls())*plans.getStdCallRate()+(bills.getNoOfStdSMS()-plans.getFreeStdSMS())*plans.getStdSMSRate()+
				(bills.getInternetDataUsageUnits()-plans.getFreeInternetDataUsageUnits())*plans.getInternetDataUsageRate();
         return totalBillAmount;
	}

	@Override
	public Customer getCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
		Customer customer = customerDao.findOne(customerID);
		if (customer == null)
			throw new CustomerDetailsNotFoundException("Customer details not found for id " + customerID);
		else
		return customer;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> getAllCustomerDetails() {
		return (List<Customer>) customerDao.findAll();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		PostpaidAccount postPaidAccount=postpaidDao.findOne(mobileNo) ;
		if(postPaidAccount==null)
			throw  new PostpaidAccountNotFoundException("Postpaid account not found for this mobile number!");
		else
			return postPaidAccount;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException {
		return postpaidDao.findAll();
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException {
		Bill billDetails=billDao.findOne(customerID);
		if(billDetails==null)
			throw new BillDetailsNotFoundException("Bill details not found for this customer!");
		else
		return billDetails;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		if(customerID==0) throw new CustomerDetailsNotFoundException("Customer id is invalid!");
		else
		return (List<Bill>) billDao.findAll();
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		return false;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		postpaidDao.remove(postPaidAccount) ;
		return false;
	}

	@Override
	public boolean removeCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
		customerDao.remove(customer);
		return false;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
		Plan planDetails=planDao.findOne(customerID);
		PostpaidAccount postpaidAccountDetails=postpaidDao.findOne(mobileNo);
		Plan plansDetails= planDao.save(new Plan(customer.getCustomerID(),postPaidAccount.getMobileNo()));
		if(planDetails==null)
			throw new PlanDetailsNotFoundException("plan details not found for this customer!");
		else if(postpaidAccountDetails==null)
			throw new PostpaidAccountNotFoundException("Postpaid account not applicable to this mobile number");
		else
		return plansDetails;
	}

	@Override
	public Customer acceptCustomerDetails(String firstName, String lastName, String emailID, String dateOfBirth,
			String billingAddressCity, String billingAddressState, int billingAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) {
		
		return customer;
	}

}
