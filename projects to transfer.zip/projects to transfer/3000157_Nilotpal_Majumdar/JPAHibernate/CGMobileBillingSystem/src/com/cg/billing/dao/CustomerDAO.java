package com.cg.billing.dao;
import java.util.HashMap;
import com.cg.billing.beans.Customer;
public interface CustomerDAO {
	Customer save(Customer customer);
	boolean update(Customer customer);
	boolean remove(Customer customer);
	Customer findOne(int i);
	HashMap<Integer,Customer> findAll();
}
