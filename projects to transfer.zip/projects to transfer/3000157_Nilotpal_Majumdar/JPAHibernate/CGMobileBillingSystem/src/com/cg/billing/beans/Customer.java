package com.cg.billing.beans;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int customerID;
	private String firstName, lastName, emailID, dateOfBirth;
	
	@Embedded
	private Map<String,Address> address;
	
	@OneToMany(mappedBy="customer")
	private Map<Long, PostpaidAccount> postpaidAccounts = new HashMap<>();
	
	@OneToMany(mappedBy="customer")
	private Map<Integer,Bill> bills=new HashMap<>();
	public Customer() {}



	public Customer(int customerID, String firstName, String lastName, String emailID, String dateOfBirth,
			Map<String,Address> address, Map<Long, PostpaidAccount> postpaidAccounts, Map<Integer, Bill> bills) {
		super();
		this.customerID = customerID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailID = emailID;
		this.dateOfBirth = dateOfBirth;
		this.address = (Map<String, Address>) address;
		this.postpaidAccounts = postpaidAccounts;
		this.bills = bills;
	}
	public Customer(int customerID) {
		super();
		this.customerID = customerID;
	}
	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Map<String, Address> getAddress() {
		return address;
	}

	public void setAddress(Map<String,Address> address) {
		this.address = (Map<String, Address>) address;
	}

	public Map<Long, PostpaidAccount> getPostpaidAccounts() {
		return postpaidAccounts;
	}

	public void setPostpaidAccounts(Map<Long, PostpaidAccount> postpaidAccounts) {
		this.postpaidAccounts = postpaidAccounts;
	}
	
	public Map<Integer, Bill> getBills() {
		return bills;
	}


	public void setBills(Map<Integer, Bill> bills) {
		this.bills = bills;
	}
	
}