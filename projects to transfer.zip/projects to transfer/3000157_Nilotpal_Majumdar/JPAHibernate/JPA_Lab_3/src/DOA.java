import java.util.List;

public interface DOA {
	 Book save(Book book);
	 Author findBook(int authorId);
	 Book findAuthor(int bookISBN);
	 List<Book>findInRange();
}
