
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Author {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int authorId;
	private String authorName;
	@OneToMany(mappedBy="author")
	private Book book;
	public Author() {}
	public Author(int authorId, String authorName) {
		super();
		this.authorId = authorId;
		this.authorName = authorName;
	}
	public Author(int authorId) {
		super();
		this.authorId = authorId;
	}
	public Author(int authorId, String authorName, Book book) {
		super();
		this.authorId = authorId;
		this.authorName = authorName;
		this.book = book;
	}
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	
	public Author(Book book) {
		super();
		this.book = book;
	}
	public Author(String authorName, Book book2) {
		this.authorName=authorName;
		this.book=book2;
	}
	@Override
	public String toString() {
		return "Author [authorId=" + authorId + ", authorName=" + authorName + ", book=" + book + "]";
	}
	
	
}