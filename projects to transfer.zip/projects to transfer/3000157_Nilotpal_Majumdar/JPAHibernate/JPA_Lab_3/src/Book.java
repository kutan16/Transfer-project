import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Book {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int bookISBN;
	private String bookTitle;
	private double bookPrice;
	@ManyToOne
	private Author author;
	public Book() {}
	public Book(int bookISBN, String bookTitle, double bookPrice, Author author) {
		super();
		this.bookISBN = bookISBN;
		this.bookTitle = bookTitle;
		this.bookPrice = bookPrice;
		this.author = author;
	}
	public Book(int bookISBN, Author author) {
		super();
		this.bookISBN = bookISBN;
		this.author = author;
	}
	public Book(String bookTitle, double bookPrice) {
		super();
		this.bookTitle=bookTitle;
		this.bookPrice=bookPrice;
	}
	public int getBookISBN() {
		return bookISBN;
	}
	public void setBookISBN(int bookISBN) {
		this.bookISBN = bookISBN;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public double getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}
	public Author getAuthor() {
		return author;
	}
	public void setAuthor(Author author) {
		this.author = author;
	}
	@Override
	public String toString() {
		return "Book [bookISBN=" + bookISBN + ", bookTitle=" + bookTitle + ", bookPrice=" + bookPrice + "]";
	}
	
}
