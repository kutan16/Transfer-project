package com.cg.github.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.github.pagebeans.LoginPage;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class GithubStepDefinition {
	
	private WebDriver driver;
	private LoginPage loginPage;
	
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\3000157_Nilotpal_Majumdar\\BDDCucumberSelenium\\chromedriver.exe");
	}
	
	@Given("^User is on the Login page$")
	public void user_is_on_the_Login_page() throws Throwable {
		driver=new ChromeDriver();
		driver.get("https://github.com/login");
		loginPage=PageFactory.initElements(driver,LoginPage.class);
		throw new PendingException();
	}

	@When("^User Enter valid username and valid passowrd$")
	public void user_Enter_valid_username_and_valid_passowrd() throws Throwable {
	    loginPage.setUsername("kutan16");
	    loginPage.setPassword("nilotpal1");
	    loginPage.toString();
	    throw new PendingException();
	}

	@Then("^Login is successful and user gets redirected to his/her account$")
	public void login_is_successful_and_user_gets_redirected_to_his_her_account() throws Throwable {
	    String actialTitle=driver.getTitle();
	    String expectedTitle="kutan16";
	    Assert.assertEquals(expectedTitle, actialTitle);
	    throw new PendingException();
	}

	@When("^User Enter invalid username and valid passowrd$")
	public void user_Enter_invalid_username_and_valid_passowrd() throws Throwable {
	    loginPage.setUsername("kutan1612");
	    loginPage.setPassword("nilotpal1");
	    loginPage.clickSignIn();
	    throw new PendingException();
	}

	@Then("^Login is Unsuccessful and user gets a \"(.*?)\" message$")
	public void login_is_Unsuccessful_and_user_gets_a_message(String arg1) throws Throwable {
	    String expectedErrorMessage="Incorrect username or password";
	    Assert.assertEquals(expectedErrorMessage, loginPage.getActualErrorMessage());
	    throw new PendingException();
	}

	@When("^User Enter valid username and invalid passowrd$")
	public void user_Enter_valid_username_and_invalid_passowrd() throws Throwable {
	    loginPage.setUsername("kutan16");
	    loginPage.setPassword("kutan1");
	    loginPage.clickSignIn();
	    throw new PendingException();
	}

	@Then("^Login is unsuccessful and user gets a \"(.*?)\" messgae$")
	public void login_is_unsuccessful_and_user_gets_a_messgae(String arg1) throws Throwable {
		String expectedErrorMessage="Incorrect username or password";
	    Assert.assertEquals(expectedErrorMessage, loginPage.getActualErrorMessage());
	    throw new PendingException();
	}
	
}
