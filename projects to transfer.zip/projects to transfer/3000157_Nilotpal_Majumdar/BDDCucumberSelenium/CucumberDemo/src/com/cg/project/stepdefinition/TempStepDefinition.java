package com.cg.project.stepdefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TempStepDefinition {

	@Given("^User is at the login page$")
	public void user_is_at_the_login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User inputs his/her credentials for login$")
	public void user_inputs_his_her_credentials_for_login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^OTP is asked for the confirmation of login$")
	public void otp_is_asked_for_the_confirmation_of_login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}
}
