package com.cg.register.pagebeans;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class RegistrationPage {
	private WebDriver driver;
	
	@FindBy(how=How.ID_OR_NAME,id="userid")
	private WebElement userid;
	
	@FindBy(how=How.ID_OR_NAME,id="passid")
	private WebElement password;
	
	@FindBy(how=How.ID_OR_NAME,id="username")
	private WebElement name;
	
	@FindBy(how=How.ID_OR_NAME,id="address")
	private WebElement address;
	
	@FindBy(how=How.ID_OR_NAME,id="country")
	private WebElement country =driver.findElement(By.id("country"));
	Select dropdown= new Select(country);
	
	@FindBy(how=How.ID_OR_NAME,id="zip")
	private WebElement zipCode;
	
	@FindBy(how=How.ID_OR_NAME,id="email")
	private WebElement email;
	
	@FindBy(how=How.ID_OR_NAME,id="gender")
	private WebElement radio1=driver.findElement(By.id("Male"));
	private WebElement radio2=driver.findElement(By.id("Female"));
	
	@FindBy(className="btn")
	private WebElement button;
	
	@FindBy(how=How.XPATH,xpath="//div[@class='container']\" ")
	private WebElement actualErrorMessage;
	
	public RegistrationPage() {}

	public String getUserid() {
		return userid.getAttribute("value");
	}

	public void setUserid(String userid) {
		this.userid.sendKeys(userid);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.userid.sendKeys(password);
	}

	public WebElement getButton() {
		return button;
	}


	public String getActualErrorMessage() {
		return actualErrorMessage.getText();
	}

	public void setActualErrorMessage(WebElement actualErrorMessage) {
		this.actualErrorMessage = actualErrorMessage;
	}

	public void clickSignIn() {
		button.submit();
	}
}
