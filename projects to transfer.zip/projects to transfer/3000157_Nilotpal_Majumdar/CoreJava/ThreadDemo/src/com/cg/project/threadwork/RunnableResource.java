package com.cg.project.threadwork;

public class  RunnableResource implements Runnable{
	public RunnableResource() {
		super();
	}
	@Override
	public void run() {
		Thread t = Thread.currentThread();
		//int i=1;
		if(t.getName().equals("tickThread"))
				for(int i=1;i<=10;i++)
					try {	
						Thread.sleep(100);
						System.out.println("tick  "+" "+i+" "+t.getName());
			}
		catch(InterruptedException e) {
			e.printStackTrace();
		}
		if(t.getName().equals("tockThread"))
				for(int i=1;i<=10;i++)
					try {
						Thread.sleep(100);
						System.out.println("tock  "+" "+i+" "+t.getName());
			}
		catch(InterruptedException e) {
			e.printStackTrace();
		}

		
		//ODD , EVEN, PRIME		
		
//		int odd=0;
//		int even=0;
//		int prime=0;
//		if(t.getName().equals("tickThread"))
//			for(int i=1;i<=100;i++) {
//				if(i%2!=0) {
//					odd=i;
//					System.out.println("tickODD"+" "+odd+" "+t.getName());
//					}
//			}
//		if(t.getName().equals("tockThread"))
//			for(int i=1;i<=100;i++) {
//				if(i%2==0) {
//					even=i;
//					System.out.println("tockEVEN"+" "+even+" "+t.getName());
//					}
//				}
//		if(t.getName().equals("kolThread"))
//			for(int i=1;i<=100;i++) {
//				int counter=0;
//				for(int j=i;j>=1;j--)
//				if(i%j==0) {
//					counter=counter+1;
//				}
//				if(counter==2) {
//					prime=i;
//					System.out.println("kolPRIME"+" "+prime+" "+t.getName());
//					}
//				}
		System.out.println("End of thread task");
	}
}

