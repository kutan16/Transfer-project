package com.cg.equals.client;

import com.cg.equals.bean.Employee;

public class MainClass {
	public static void main(String args[]) {
		Employee emp1  = new Employee(111,"nilotpal","majumdar",12000);
		Employee emp2  = new Employee(111,"nilotpal","majumdar",2112);
		Object obj=emp2;
		if(emp1==(emp2)) {
			System.out.println("same data");
		}
		else
			System.out.println("not same");
		if(obj.equals(emp2)) {
			System.out.println("hm");
		}
	}
}
