package com.cg.wrapper.main;

public class MainClass {
	public static void main(String args[]) {
		int num1 = 100;
		Integer iob1=new Integer(num1); //auto boxing
		//iob1 = num1;
		Integer iob2=new Integer(50);
		int num2=iob2; //auto unboxing
		
		//iob1=num1+100+iob2;
		System.out.println(iob1); 
		System.out.println(iob1.equals(100));
		System.out.println(num2);
		
	}
}
