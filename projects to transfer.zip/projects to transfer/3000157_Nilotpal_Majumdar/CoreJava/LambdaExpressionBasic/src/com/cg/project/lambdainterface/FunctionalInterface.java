package com.cg.project.lambdainterface;

public interface FunctionalInterface {
	
	void greetUser(String firstName,String lastName);
}
