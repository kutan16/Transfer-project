package com.cg.project.service;

public interface WorkService {
	void doSomeWork();

}
