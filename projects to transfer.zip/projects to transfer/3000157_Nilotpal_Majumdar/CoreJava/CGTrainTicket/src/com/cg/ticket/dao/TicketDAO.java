package com.cg.ticket.dao;

import java.util.List;

import com.cg.ticket.beans.Ticket;



public interface TicketDAO {
	Ticket save(Ticket ticket);
	boolean update(Ticket ticket);
	Ticket findOne(int ticketId);
	List<Ticket>findAll();
}
