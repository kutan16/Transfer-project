package com.cg.ticket.dao;

import java.util.List;

import com.cg.ticket.beans.Ticket;

public class TicketDAOImpl implements TicketDAO {

	@Override
	public Ticket save(Ticket ticket) {
		
		return null;
	}

	@Override
	public boolean update(Ticket ticket) {
		
		return false;
	}

	@Override
	public Ticket findOne(int ticketId) {
		
		return null;
	}

	@Override
	public List<Ticket> findAll() {
		
		return null;
	}

}
