package com.cg.ticket.beans;

public class Ticket {
	private int trainId;
	private String userName;
	private int seats;
	private String destination;
	private String departure;
	private float charges;
	public Ticket() {
		
	}
	public Ticket(int trainId, String userName, int seats, String destination, String departure, float charges) {
		super();
		this.trainId = trainId;
		this.userName = userName;
		this.seats = seats;
		this.destination = destination;
		this.departure = departure;
		this.charges = charges;
	}
	public int getTrainId() {
		return trainId;
	}
	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getDeparture() {
		return departure;
	}
	public void setDeparture(String departure) {
		this.departure = departure;
	}
	public float getCharges() {
		return charges;
	}
	public void setCharges(float charges) {
		this.charges = charges;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(charges);
		result = prime * result + ((departure == null) ? 0 : departure.hashCode());
		result = prime * result + ((destination == null) ? 0 : destination.hashCode());
		result = prime * result + seats;
		result = prime * result + trainId;
		result = prime * result + ((userName == null) ? 0 : userName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ticket other = (Ticket) obj;
		if (Float.floatToIntBits(charges) != Float.floatToIntBits(other.charges))
			return false;
		if (departure == null) {
			if (other.departure != null)
				return false;
		} else if (!departure.equals(other.departure))
			return false;
		if (destination == null) {
			if (other.destination != null)
				return false;
		} else if (!destination.equals(other.destination))
			return false;
		if (seats != other.seats)
			return false;
		if (trainId != other.trainId)
			return false;
		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Ticket [trainId=" + trainId + ", userName=" + userName + ", seats=" + seats + ", destination="
				+ destination + ", departure=" + departure + ", charges=" + charges + "]";
	}
	
}
