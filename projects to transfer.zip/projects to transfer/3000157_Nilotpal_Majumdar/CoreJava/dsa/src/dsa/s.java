package dsa;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class s {
	public static void main(String args[]) {
		doSomething();
	}
	private static void doSomething() {
		try{
			doSomethingElse();
		}
		catch (Exception e) {
			// TODO: handle exception
		}
	}
	private static void doSomethingElse() {
		try {
			throw new Exception();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
