 class Flower{
		public void fragrance() {
			System.out.println("Flower");
	 }
		 class Rose{
				public void fragrance() {
					System.out.println("Roze");
			 }
				 class Lily{
						public void fragrance() {
							System.out.println("Lily");
					 }
						 class Bouquet{
								public void arrangeFlowers() {
								 Flower f1=new Rose();
								 Flower f2 = new Lily();
								 f1.fragrance();
							 }
						 }
				 }
		 }
	 }

