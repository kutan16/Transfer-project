package com.cg.mathproject.services;

import com.cg.mathproject.exceptions.NegativeNumberNotAllowedException;

public interface MathServices {
	public int add(int a1,int a2)throws NegativeNumberNotAllowedException;
	abstract int sub(int n1,int n2)throws NegativeNumberNotAllowedException;
	public abstract int div(int n1,int n2)throws NegativeNumberNotAllowedException;
	int multi(int n1,int n2)throws NegativeNumberNotAllowedException;
}
