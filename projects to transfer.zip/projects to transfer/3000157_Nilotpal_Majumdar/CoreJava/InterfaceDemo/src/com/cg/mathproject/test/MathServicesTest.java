package com.cg.mathproject.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mathproject.exceptions.NegativeNumberNotAllowedException;
import com.cg.mathproject.services.MathServices;
import com.cg.mathproject.services.MathServicesImpl;

public class MathServicesTest {

	//		@Test
	//		public void test() {
	//			fail("Not yet implemented");
	//		}
	private static MathServices services;
	@BeforeClass
	public static void setUpTestEnv() {
		services=new MathServicesImpl();
	}
	//add
	@Test(expected=NegativeNumberNotAllowedException.class)
	public void testAddForFirstNumberInvalid()throws NegativeNumberNotAllowedException{
		services.add(-100, 200);
	}
	@Test(expected=NegativeNumberNotAllowedException.class)
	public void testAddForSecondNumberInvalid()throws NegativeNumberNotAllowedException{
		services.add(100, -200);
	}
	@Test(expected=NegativeNumberNotAllowedException.class)
	public void testAddForBothValidNumber()throws NegativeNumberNotAllowedException{
		Assert.assertEquals(300, services.add(100, 200));
	}
	//sub
	@Test(expected=NegativeNumberNotAllowedException.class)
	public void testSubForFirstNumberInvalid()throws NegativeNumberNotAllowedException{
		services.sub(-20, 10);
	}
	@Test(expected=NegativeNumberNotAllowedException.class)
	public void testSubForSecondNumberInvalid()throws NegativeNumberNotAllowedException{
		services.sub(20, 10);
	}
	@Test(expected=NegativeNumberNotAllowedException.class)
	public void testSubForBothValidNumber()throws NegativeNumberNotAllowedException{
		Assert.assertEquals(10, services.sub(20, 10));
	}
	//div
	@Test(expected=NegativeNumberNotAllowedException.class)
	public void testDivForFirstNumberInvalid()throws NegativeNumberNotAllowedException{
		services.div(-8,4 );
	}
	@Test(expected=NegativeNumberNotAllowedException.class)
	public void testDivForSecondNumberInvalid()throws NegativeNumberNotAllowedException{
		services.div(8, -4);
	}
	@Test(expected=NegativeNumberNotAllowedException.class)
	public void testDivForBothValidNumber()throws NegativeNumberNotAllowedException{
		Assert.assertEquals(2, services.div(8, 4));
	}
	//multi
	@Test(expected=NegativeNumberNotAllowedException.class)
	public void testMultiForFirstNumberInvalid()throws NegativeNumberNotAllowedException{
		services.multi(-10, 5);
	}
	@Test(expected=NegativeNumberNotAllowedException.class)
	public void testMultiForSecondNumberInvalid()throws NegativeNumberNotAllowedException{
		services.multi(10, -5);
	}
	@Test(expected=NegativeNumberNotAllowedException.class)
	public void testMultiForBothValidNumber()throws NegativeNumberNotAllowedException{
		Assert.assertEquals(50, services.multi(10, 5));
	}
	@AfterClass
	public static void tearDownTestEnv() {
		services=null;
	}
}
