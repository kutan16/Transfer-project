package com.cg.mathproject.client;

import com.cg.mathproject.services.MathServices;
import com.cg.mathproject.services.MathServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		MathServices ob = new MathServicesImpl();
	}

}
