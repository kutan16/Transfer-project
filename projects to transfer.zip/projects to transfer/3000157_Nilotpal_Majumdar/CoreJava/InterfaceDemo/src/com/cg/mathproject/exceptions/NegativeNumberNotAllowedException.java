package com.cg.mathproject.exceptions;

@SuppressWarnings("serial")
public class NegativeNumberNotAllowedException extends Exception{
	public NegativeNumberNotAllowedException() {
		// TODO Auto-generated constructor stub
	}
}
