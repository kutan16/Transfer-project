package com.cg.project.collections;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Set;

import com.cg.project.beans.Associate;

public class MapClassesDemo {
	public static void hashTableClassWork( ) {
		Hashtable<Integer,Associate>associates=new Hashtable<>();
	
		associates.put(111,new Associate(111,"satish","mahajan",15000));
		associates.put(114,new Associate(114,"kumar","raj",44222));
		associates.put(112,new Associate(112,"ayush","patil",17980));
		associates.put(114,new Associate(114,"mayur","patil",13499));
		associates.put(111,new Associate(111,"Nilesh","kumar",12000));
	
		System.out.println(associates);
	
		Associate associate = associates.get(112);
		associates.remove(112);
		Set<Integer>keys=associates.keySet();
	
		for(Integer key : keys) {
			System.out.println(associates.get(key));
		}
			ArrayList<Associate>associateList=new ArrayList<>(associates.values());
		}
}
