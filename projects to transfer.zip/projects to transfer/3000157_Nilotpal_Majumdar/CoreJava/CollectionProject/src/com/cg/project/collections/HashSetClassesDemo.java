package com.cg.project.collections;

import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import com.cg.project.beans.Associate;

public class HashSetClassesDemo {
	public static void HashSetClassDemo() {
		HashSet<String> strList=new HashSet<>();
		
		HashSet<Associate>associates=new HashSet<Associate>();
		associates.add(new Associate(111,"satish","mahajan",12000));
		associates.add(new Associate(114,"kumar","raj",12000));
		associates.add(new Associate(112,"ayush","patil",12000));
		associates.add(new Associate(114,"mayur","patil",12000));
		associates.add(new Associate(111,"Nilesh","kumar",12000));
		
		System.out.println(associates);
				
		Associate associateToBeSearched=new Associate(114,"Mayur","patil",13499);
		System.out.println(associates.contains(associateToBeSearched));
	
		
		}
	}

