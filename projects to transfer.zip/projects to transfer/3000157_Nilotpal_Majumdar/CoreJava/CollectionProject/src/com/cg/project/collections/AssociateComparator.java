package com.cg.project.collections;

import java.util.Comparator;

import com.cg.project.beans.Associate;

public class AssociateComparator implements Comparator<Associate>{

	public int compareTo(Object o1,Object o2) {
		
		return o1.getBasicSalary-o2.getBasicSalary;
	}

}
