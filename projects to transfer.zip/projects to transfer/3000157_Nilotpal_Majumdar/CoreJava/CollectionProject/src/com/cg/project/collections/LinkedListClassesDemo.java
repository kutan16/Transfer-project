package com.cg.project.collections;

import java.util.Collections;
import java.util.LinkedList;

import com.cg.project.beans.Associate;

public class LinkedListClassesDemo {
	public static void linkedListClassDemo() {
		LinkedList<String> strList=new LinkedList<>();
		
		LinkedList<Associate>associates=new LinkedList<Associate>();
		associates.add(new Associate(111,"satish","mahajan",12000));
		associates.add(new Associate(114,"kumar","raj",44222));
		associates.add(new Associate(112,"ayush","patil",17980));
		associates.add(new Associate(114,"mayur","patil",13499));
		associates.add(new Associate(111,"Nilesh","kumar",12000));
		
		System.out.println(associates);
				
		Associate associateToBeSearched=new Associate(114,"Mayur","patil",13499);
		System.out.println(associates.contains(associateToBeSearched));
	
		Collections.sort(associates);
		for(Associate associate: associates) {
			System.out.println(associate);
		}
	}
}
