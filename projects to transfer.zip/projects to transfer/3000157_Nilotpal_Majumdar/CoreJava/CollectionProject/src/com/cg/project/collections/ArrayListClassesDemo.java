package com.cg.project.collections;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;

import com.cg.project.beans.Associate;

public class ArrayListClassesDemo {
	public static void arrayListClassDemo()
	{
		ArrayList<String> strList=new ArrayList<>();
		
		
//		  //insert
//		  
//		  strList.add("satish"); strList.add("kumar"); strList.add("nilesh");
//		  strList.add("rakesh"); strList.add("ayush"); strList.add("satish");
//		  strList.add("mayur");
//		  
//		  System.out.println(strList);
//		  
//		  //search 
//		  String nameToBeSearched="ayush";
//		  System.out.println(strList.contains(nameToBeSearched));
//		  
//		  //sort 
//		  Collections.sort(strList); for(String i:strList ) {
//		  System.out.println(strList); }
//		  
//		  //remove 
//		  String nameToBeRemoved="satish";
//		  System.out.println(strList.remove(nameToBeRemoved));
//		  
//		  //iterate
//		 
		
		ArrayList<Associate>associates=new ArrayList<Associate>();
		associates.add(new Associate(111,"satish","mahajan",12000));
		associates.add(new Associate(114,"kumar","raj",12000));
		associates.add(new Associate(112,"ayush","patil",12000));
		associates.add(new Associate(114,"mayur","patil",12000));
		associates.add(new Associate(111,"Nilesh","kumar",12000));
		
		System.out.println(associates);
				
		Associate associateToBeSearched=new Associate(114,"Mayur","patil",13499);
		System.out.println(associates.contains(associateToBeSearched));
	
		//sorting
		Collections.sort(associates);
		for(Associate associate: associates) {
			System.out.println(associate);
		}
//		System.out.println("=========================");
//		Collections.sort(associates,new AssociateComparator());
//		for(Associate associate : associates) {
//			System.out.println(associate);
		
		
		
		}
	}

