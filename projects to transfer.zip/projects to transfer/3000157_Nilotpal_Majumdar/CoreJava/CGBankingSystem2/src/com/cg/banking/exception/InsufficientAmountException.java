package com.cg.banking.exception;

public class InsufficientAmountException extends Exception {

}
