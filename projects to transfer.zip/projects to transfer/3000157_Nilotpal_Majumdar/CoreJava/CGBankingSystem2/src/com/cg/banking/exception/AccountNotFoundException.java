package com.cg.banking.exception;

public class AccountNotFoundException extends Exception{

}
