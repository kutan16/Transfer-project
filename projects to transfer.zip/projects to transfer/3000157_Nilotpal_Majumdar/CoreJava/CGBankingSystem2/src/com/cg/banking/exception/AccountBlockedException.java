package com.cg.banking.exception;

public class AccountBlockedException extends Exception {
	
}
