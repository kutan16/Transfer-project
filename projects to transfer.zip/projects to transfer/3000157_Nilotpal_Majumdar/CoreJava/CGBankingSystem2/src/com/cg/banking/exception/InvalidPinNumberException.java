package com.cg.banking.exception;

public class InvalidPinNumberException extends Exception {

}
