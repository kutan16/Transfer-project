package com.cg.banking.client;

import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.exception.AccountBlockedException;
import com.cg.banking.exception.AccountNotFoundException;
import com.cg.banking.exception.BankingServicesDownException;
import com.cg.banking.exception.InvalidAccountTypeException;
import com.cg.banking.exception.InvalidAmountException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {

	public static void main(String[] args) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		BankingServices services = new BankingServicesImpl();
//		Scanner sc = new Scanner(System.in);
		Account account1 = new Account();
		Account account2 = new Account();
//		System.out.println("Enter your choice");
//		System.out.println("1. create Account");
//		System.out.println("2. get account details");
//		System.out.println("5. exit");
//		int n=sc.nextInt();
//		do {
//			switch(n) {
//				case 1:
					account1=services.openAccount("savings", 10000);
					account1.setAccountStatus("open");
					account2=services.openAccount("salary", 12000);
					account2.setAccountStatus("open");
					System.out.println("Account created");
//					break; 
		
		System.out.println("Account = "+account1);
		System.out.println("Account = "+account2);
//				case 2:
					System.out.println("\n --------\n account details generated \n--------------");
					System.out.println("account id : "+account1.getAccountNo()+"\n"+services.getAccountDetails(account1.getAccountNo()));
					System.out.println("account id : "+account2.getAccountNo()+"\n"+services.getAccountDetails(account2.getAccountNo()));
//					break;
//				default:
//					System.out.priln("enter correct choice");
//			}nt
//		}
//		while(n!=5);
	}
}