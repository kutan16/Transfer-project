package com.cg.banking.beans;
import java.util.List;
public class Account {
	private long accountNo;
	private int pinNumber;
	private String accountType,accountStatus;
	private float accountBalance;
	private List<Transaction>transactions;
}
