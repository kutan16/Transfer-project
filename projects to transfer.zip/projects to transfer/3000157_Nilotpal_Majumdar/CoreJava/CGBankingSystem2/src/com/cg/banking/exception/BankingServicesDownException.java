package com.cg.banking.exception;

public class BankingServicesDownException extends Exception {

}
