package com.cg.banking.exception;

public class InvalidAccountTypeException extends Exception {

}
