package com.cg.project.innerdemo;

public class HotelClass {
	interface FoodOrderListner {
		void cookAFood(String foodName);
	}
	static class VegKitchen implements FoodOrderListner{
		@Override
		public void cookAFood(String foodName) {
			System.out.println(foodName+"  is ready ");
		}
	}
	static class NonVegKitchen implements FoodOrderListner{
		@Override
		public void cookAFood(String foodName) {
			System.out.println(foodName+ " is ready");
		}
	}
}
