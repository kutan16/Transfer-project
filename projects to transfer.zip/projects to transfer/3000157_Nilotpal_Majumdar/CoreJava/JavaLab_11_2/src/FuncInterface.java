interface FuncInterface 
{ 
	void abstractFun(String str); 
	default void normalFun() 
	{ 
		System.out.println("Capgemini"); 
	} 
} 