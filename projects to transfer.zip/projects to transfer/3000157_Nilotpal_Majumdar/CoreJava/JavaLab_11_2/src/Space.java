import java.util.function.Function;
import java.util.function.Supplier;

public class Space {
	public static void main(String args[])
	{
		Supplier<String> supplier = () -> "capgemini";
		System.out.println(supplier);
		Function<String, Integer>len = () -> supplier.length();
	}
}
