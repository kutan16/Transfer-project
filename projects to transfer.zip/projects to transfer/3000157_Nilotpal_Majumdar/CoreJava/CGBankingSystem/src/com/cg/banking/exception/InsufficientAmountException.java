package com.cg.banking.exception;

public class InsufficientAmountException extends Exception {
	public InsufficientAmountException() {
		super("WITHDRAW AMOUNT EXCEEDS CURRENT BALANCE \t");
	}	
}
