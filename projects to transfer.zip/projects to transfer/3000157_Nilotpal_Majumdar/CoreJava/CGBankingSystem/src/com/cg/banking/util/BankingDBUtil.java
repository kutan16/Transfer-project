package com.cg.banking.util;

import java.util.HashMap;

import com.cg.banking.beans.Account;

public class BankingDBUtil {
public static HashMap<Integer, Account>account = new HashMap<>();
	
private static int ACCOUNT_ID_COUNTER=100;
private static int TRANSACTION_ID_COUNTER=1000;
public static String accountStatus="Active";
	
	public static int getACCOUNT_ID_COUNTER() {
		return ++ACCOUNT_ID_COUNTER;
	}
	public static int getTRANSACTION_ID_COUNTER() {
		return ++TRANSACTION_ID_COUNTER;
	}
	public static int getPin() {
		return (int) (Math.random()*10000);
	}
	public static String getAccountStatus() {
		return accountStatus;
	}
}
