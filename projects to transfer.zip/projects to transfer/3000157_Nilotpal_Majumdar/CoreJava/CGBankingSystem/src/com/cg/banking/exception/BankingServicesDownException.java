package com.cg.banking.exception;

public class BankingServicesDownException extends Exception {
	public BankingServicesDownException() {
		super("BANKING SERVICES ARE DOWN RIGHT NOW. TRY AGAIN LATER \t");
	}
}
