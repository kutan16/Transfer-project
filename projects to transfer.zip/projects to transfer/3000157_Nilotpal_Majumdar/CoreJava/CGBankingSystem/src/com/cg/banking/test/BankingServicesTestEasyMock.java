package com.cg.banking.test;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

class BankingServicesTestEasyMock {
	
	private static BankingServices bankingServices;
	private static AccountDAO mockAccountDao;

	@BeforeClass
	public static void setUpTestEnv() {
		mockAccountDao=EasyMock.mock(AccountDAO.class);
		bankingServices=new BankingServicesImpl(mockAccountDao);
	}

	@Before
	public void setUpTestMockData() {
	
	}
	
	@After
	public void tearDownTestMockData() {
		EasyMock.resetToDefault(mockAccountDao);
	}
	
	@AfterClass
	public static void tearDownTestEnv() {
		mockAccountDao=null;
		bankingServices=null;
	}
}

