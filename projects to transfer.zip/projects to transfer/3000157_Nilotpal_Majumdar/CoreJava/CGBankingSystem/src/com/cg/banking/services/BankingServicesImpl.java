package com.cg.banking.services;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.exception.AccountBlockedException;
import com.cg.banking.exception.AccountNotFoundException;
import com.cg.banking.exception.BankingServicesDownException;
import com.cg.banking.exception.InsufficientAmountException;
import com.cg.banking.exception.InvalidAccountTypeException;
import com.cg.banking.exception.InvalidAmountException;
import com.cg.banking.exception.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {
	private AccountDAO accountDAO = new AccountDAOImpl();

	public BankingServicesImpl(AccountDAO mockAccountDao) {
		// TODO Auto-generated constructor stub
	}

	public BankingServicesImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account account = new Account(accountType,initBalance);
//		if(accountType!="savings"||accountType!="current"||accountType!="CURRENT"||accountType!="SAVINGS"||accountType!="Current"||accountType!="Savings")
//			throw new InvalidAccountTypeException();
		if(initBalance<500)
			throw new InvalidAmountException();
		else{account=accountDAO.save(account);}
		return account;
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
			Account account = accountDAO.findOne((int) accountNo);
			float finalAmount = account.getAccountBalance()+amount;
			account.setAccountBalance(finalAmount);
			return finalAmount;
//		return 0;
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account account = accountDAO.findOne((int)accountNo);
		float finalBalance;
		if(pinNumber==account.getPinNumber()) {
			finalBalance=account.getAccountBalance()-amount;
			if(amount>account.getAccountBalance())
				throw new InsufficientAmountException();
			else
				account.setAccountBalance(finalBalance);
		}
		else {
			throw new InvalidPinNumberException();
		}
		return finalBalance;
		
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		
		depositAmount(accountNoTo, transferAmount);
		withdrawAmount(accountNoFrom, transferAmount, pinNumber);
		
		return false;
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account = accountDAO.findOne((int) accountNo);
		if(account==null)
			throw new AccountNotFoundException();
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		return accountDAO.findAll();
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		// TODO Auto-generated method stub
		return null;
	}

}
