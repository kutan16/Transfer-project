package com.cg.banking.test;

import java.util.HashMap;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exception.AccountNotFoundException;
import com.cg.banking.exception.BankingServicesDownException;
import com.cg.banking.exception.InsufficientAmountException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class BankingServicesTest {

	private static BankingServices services;

	@BeforeClass
	public static void setUpTestEnv() {
		services=new BankingServicesImpl();
	}
	
	@Test(expected=AccountNotFoundException.class)
	public void testGetAccountDetailsForInvalidAccountId() throws AccountNotFoundException, BankingServicesDownException {
		services.getAccountDetails(1000);
	}
	
	@Test(expected=AccountNotFoundException.class)
	public void testGetAccountDetailsForValidAccountId() throws AccountNotFoundException, BankingServicesDownException {
		Account expectedAccount = new Account(101, 6554, "savings", "Active", 200, new HashMap<Integer, Transaction>(1) );
		Account actualAccount=services.getAccountDetails(101);
		Assert.assertEquals(expectedAccount, actualAccount);
	}
	
	@Test
	public void testGetAccountDetailsforInvalidAmount() throws AccountNotFoundException, BankingServicesDownException {
		Account expectedAmount = new Account(101, 6554, "savings", "Active", 200, new HashMap<Integer, Transaction>(1) );
		Account actualAmount = services.getAccountDetails(101);
		Assert.assertEquals(expectedAmount, actualAmount);
	}
	
	@AfterClass
	public static void tearDownTestEnv() {
	services=null;
	}
}
