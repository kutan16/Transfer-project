package com.cg.banking.exception;

public class InvalidPinNumberException extends Exception {
	public InvalidPinNumberException() {
		super("PIN NUMBER IS INVALID \t");
	}
}
