package com.cg.banking.exception;

public class AccountNotFoundException extends Exception{
	public AccountNotFoundException() {
		super("ACCOUNT DOES NOT EXIST \t");
	}
}
