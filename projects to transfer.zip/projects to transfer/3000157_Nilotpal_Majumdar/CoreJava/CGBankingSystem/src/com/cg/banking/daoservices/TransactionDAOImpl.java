package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Transaction;
import com.cg.banking.util.BankingDBUtil;

public class TransactionDAOImpl implements TransactionDAO {

	@Override
	public Transaction save(int accountNo,Transaction transaction) {
		transaction.setTransactionId(BankingDBUtil.getTRANSACTION_ID_COUNTER());
		BankingDBUtil.account.get(accountNo).getTransactions().put(transaction.getTransactionId(), transaction);
		return transaction;
	}

	@Override
	public boolean update(Transaction transaction) {
		return false;
	}

	@Override
	public Transaction findOne(int accountNo,int transactionId) {
		return BankingDBUtil.account.get(accountNo).getTransactions().get(transactionId);
	}

	@Override
	public List<Transaction> findAll(int accountNo) {
		
		return new ArrayList<Transaction>(BankingDBUtil.account.get(accountNo).getTransactions().values());
	}

}
