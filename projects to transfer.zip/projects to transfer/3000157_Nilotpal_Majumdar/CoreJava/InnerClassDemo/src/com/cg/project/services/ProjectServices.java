package com.cg.project.services;

public interface ProjectServices {
	void developProject();
	
}
