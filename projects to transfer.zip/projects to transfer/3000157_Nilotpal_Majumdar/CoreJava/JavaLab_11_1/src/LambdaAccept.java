class LambdaAccept
{ 
    public static void main(String args[]) 
    { 
        // lambda expression to implement above 
        // functional interface. This interface 
        // by default implements abstractFun() 
        FuncInterface fobj = (double x,double y)->System.out.println(Math.pow(x, y)); 
  
        // This calls above lambda expression and prints 10. 
        fobj.abstractFun(5,6); 
    } 
}