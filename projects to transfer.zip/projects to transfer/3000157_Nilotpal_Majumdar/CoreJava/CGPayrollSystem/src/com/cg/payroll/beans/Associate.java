package com.cg.payroll.beans;

public class Associate {

	private int associateID;
	private int yearlyInvestmentUnder80C;
	private String firstName,lastName,departmnet,designation,pancard,emailId;

	private Salary salary;
	private BankDetails bankDetails;

	public Associate() {
	}
	public Associate(int yearlyInvestmentUnder80C, String firstName, String lastName, String departmnet,
			String designation, String pancard, String emailId) {
		super();
		this.yearlyInvestmentUnder80C = yearlyInvestmentUnder80C;
		this.firstName = firstName;
		this.lastName = lastName;
		this.departmnet = departmnet;
		this.designation = designation;
		this.pancard = pancard;
		this.emailId = emailId;
	}
	public Associate(int associateID, int yearlyInvestmentUnder80C, String firstName, String lastName,
			String departmnet, String designation, String pancard, String emailId) {
		super();
		this.associateID = associateID;
		this.yearlyInvestmentUnder80C = yearlyInvestmentUnder80C;
		this.firstName = firstName;
		this.lastName = lastName;
		this.departmnet = departmnet;
		this.designation = designation;
		this.pancard = pancard;
		this.emailId = emailId;
	}
	public Associate(int yearlyInvestmentUnder80C2, String firstName2, String lastName2, String departmnet2,
			String designation2, String pancard2, String emailId2, Salary salary2, BankDetails bankDetails2) {
		// TODO Auto-generated constructor stub
	}
	public Associate(int i, int j, String string, String string2, String string3, String string4, String string5,
			String string6, Salary salary2, BankDetails bankDetails2) {
		// TODO Auto-generated constructor stub
	}
	public int getAssociateID() {
		return associateID;
	}
	public void setAssociateID(int associateID) {
		this.associateID = associateID;
	}
	public int getYearlyInvestmentUnder80C() {
		return yearlyInvestmentUnder80C;
	}
	public void setYearlyInvestmentUnder80C(int yearlyInvestmentUnder80C) {
		this.yearlyInvestmentUnder80C = yearlyInvestmentUnder80C;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDepartmnet() {
		return departmnet;
	}
	public void setDepartmnet(String departmnet) {
		this.departmnet = departmnet;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + associateID;
		result = prime * result + ((departmnet == null) ? 0 : departmnet.hashCode());
		result = prime * result + ((designation == null) ? 0 : designation.hashCode());
		result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((pancard == null) ? 0 : pancard.hashCode());
		result = prime * result + yearlyInvestmentUnder80C;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Associate other = (Associate) obj;
		if (associateID != other.associateID)
			return false;
		if (departmnet == null) {
			if (other.departmnet != null)
				return false;
		} else if (!departmnet.equals(other.departmnet))
			return false;
		if (designation == null) {
			if (other.designation != null)
				return false;
		} else if (!designation.equals(other.designation))
			return false;
		if (emailId == null) {
			if (other.emailId != null)
				return false;
		} else if (!emailId.equals(other.emailId))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (pancard == null) {
			if (other.pancard != null)
				return false;
		} else if (!pancard.equals(other.pancard))
			return false;
		if (yearlyInvestmentUnder80C != other.yearlyInvestmentUnder80C)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Associate [associateID=" + associateID + ", yearlyInvestmentUnder80C=" + yearlyInvestmentUnder80C
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", departmnet=" + departmnet
				+ ", designation=" + designation + ", pancard=" + pancard + ", emailId=" + emailId + "]";
	}


}
