package com.cg.payroll.client;

import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {
	public static void main(String args[]) throws AssociateDetailNotFoundException {
		PayrollServices services = new PayrollServicesImpl();
		//use switch case
		int associateId=services.acceptAssociateDetails("nilotpal", "majumdar"," kutan16@gmail.com", "cse","a4", "87asd513216", 5000, 3000, 1000, 1000,794651, "sbi", "sbin007263");
		System.out.println("Associate Id : "+associateId);
		int associateId1=services.acceptAssociateDetails("kutan", "lock"," lock@gmail.com", "ece","a4", "234235ds2", 7000, 4000, 1000, 1000,3246521, "sbi", "sbin007263");
		System.out.println("Associate Id : "+associateId1);
		double net1=services.calculateNetSalary(associateId);
		System.out.println("net salary = "+net1);
		double net2=services.calculateNetSalary(associateId1);
		System.out.println("net salary = "+net2);
	}
}
