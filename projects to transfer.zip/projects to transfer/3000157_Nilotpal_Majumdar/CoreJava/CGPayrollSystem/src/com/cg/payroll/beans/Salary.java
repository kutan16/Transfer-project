package com.cg.payroll.beans;

public class Salary {

	private int basicSalary,hra,conveyanceAllowance;
	private double otherAllowance,personalAllowance,monthlyTax,epf;
	private double companyPf,netSalary;
	
	public Salary() {
	}
	
	public Salary(int basicSalary, double epf, double companyPf) {
		super();
		this.basicSalary = basicSalary;
		this.epf = epf;
		this.companyPf = companyPf;
	}

	public Salary(int basicSalary, int hra, int conveyanceAllowance, double otherAllowance, double personalAllowance,
			double monthlyTax, double epf, double companyPf, double netSalary) {
		super();
		this.basicSalary = basicSalary;
		this.hra = hra;
		this.conveyanceAllowance = conveyanceAllowance;
		this.otherAllowance = otherAllowance;
		this.personalAllowance = personalAllowance;
		this.monthlyTax = monthlyTax;
		this.epf = epf;
		this.companyPf = companyPf;
		this.netSalary = netSalary;
	}

	public int getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}

	public int getHra() {
		return hra;
	}

	public void setHra(int hra) {
		this.hra = hra;
	}

	public int getConveyanceAllowance() {
		return conveyanceAllowance;
	}

	public void setConveyanceAllowance(int conveyanceAllowance) {
		this.conveyanceAllowance = conveyanceAllowance;
	}

	public double getOtherAllowance() {
		return otherAllowance;
	}

	public void setOtherAllowance(double otherAllowance) {
		this.otherAllowance = otherAllowance;
	}

	public double getPersonalAllowance() {
		return personalAllowance;
	}

	public void setPersonalAllowance(double personalAllowance) {
		this.personalAllowance = personalAllowance;
	}

	public double getMonthlyTax() {
		return monthlyTax;
	}

	public void setMonthlyTax(double monthlyTax) {
		this.monthlyTax = monthlyTax;
	}

	public double getEpf() {
		return epf;
	}

	public void setEpf(double epf) {
		this.epf = epf;
	}

	public double getCompanyPf() {
		return companyPf;
	}

	public void setCompanyPf(double companyPf) {
		this.companyPf = companyPf;
	}

	public double getNetSalary() {
		return netSalary;
	}

	public void setNetSalary(double netSalary) {
		this.netSalary = netSalary;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + basicSalary;
		long temp;
		temp = Double.doubleToLongBits(companyPf);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + conveyanceAllowance;
		temp = Double.doubleToLongBits(epf);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + hra;
		temp = Double.doubleToLongBits(monthlyTax);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(netSalary);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(otherAllowance);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(personalAllowance);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Salary other = (Salary) obj;
		if (basicSalary != other.basicSalary)
			return false;
		if (Double.doubleToLongBits(companyPf) != Double.doubleToLongBits(other.companyPf))
			return false;
		if (conveyanceAllowance != other.conveyanceAllowance)
			return false;
		if (Double.doubleToLongBits(epf) != Double.doubleToLongBits(other.epf))
			return false;
		if (hra != other.hra)
			return false;
		if (Double.doubleToLongBits(monthlyTax) != Double.doubleToLongBits(other.monthlyTax))
			return false;
		if (Double.doubleToLongBits(netSalary) != Double.doubleToLongBits(other.netSalary))
			return false;
		if (Double.doubleToLongBits(otherAllowance) != Double.doubleToLongBits(other.otherAllowance))
			return false;
		if (Double.doubleToLongBits(personalAllowance) != Double.doubleToLongBits(other.personalAllowance))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Salary [basicSalary=" + basicSalary + ", hra=" + hra + ", conveyanceAllowance=" + conveyanceAllowance
				+ ", otherAllowance=" + otherAllowance + ", personalAllowance=" + personalAllowance + ", monthlyTax="
				+ monthlyTax + ", epf=" + epf + ", companyPf=" + companyPf + ", netSalary=" + netSalary + "]";
	}
	
	
}
