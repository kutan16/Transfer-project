package com.cg.eis.bean;

public enum InsuranceScheme {
	SchemeC,SchemeB,SchemeA,NoScheme;
}
